<?php
require_once __DIR__ . '/init.php';
$pageTitle = $pageTitle ?? 'StayNest';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= e($_SESSION['csrf']) ?>">
  <title><?= e($pageTitle) ?> | StayNest</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="assets/css/style.css" rel="stylesheet">
</head>
<body data-logged-in="<?= is_logged_in() ? '1' : '0' ?>">
<nav class="navbar navbar-expand-md sn-nav">
  <div class="container">
    <a class="navbar-brand sn-brand" href="index.php"><i class="bi bi-house-heart-fill"></i> StayNest</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto align-items-md-center gap-md-2">
        <li class="nav-item"><a class="nav-link" href="index.php">Browse PGs</a></li>
        <?php if (is_logged_in()): ?>
          <li class="nav-item"><a class="nav-link" href="shortlist.php"><i class="bi bi-heart"></i> My shortlist</a></li>
          <li class="nav-item"><span class="nav-link sn-hi">Hi, <?= e($_SESSION['user_name']) ?></span></li>
          <li class="nav-item"><a class="btn btn-sm btn-outline-light" href="logout.php">Log out</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="login.php">Log in</a></li>
          <li class="nav-item"><a class="btn btn-sm sn-btn" href="signup.php">Sign up</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<main class="container py-4">
